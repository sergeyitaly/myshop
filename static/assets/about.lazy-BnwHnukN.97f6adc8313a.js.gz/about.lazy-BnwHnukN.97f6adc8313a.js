import{c as t,j as o}from"./index-1dCtYtjo.js";const r=t("/about")({component:e});function e(){return o.jsx("div",{children:o.jsx("h3",{children:"Welcome About!"})})}export{r as Route};
